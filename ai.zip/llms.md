# fiji.core.ig#1.0.0: Fiji Core FHIR Implementation Guide

## Pages

* [Home](index.md)
* [Gettingstarted](gettingstarted.md)
* [LICENSE](LICENSE.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Resource Profiles

* [FijiAllergyIntolerance](StructureDefinition-FijiAllergyIntolerance.md)
* [FijiCondition](StructureDefinition-FijiCondition.md)
* [FijiOrganization](StructureDefinition-FijiOrganization.md)
* [Fiji Patient](StructureDefinition-fiji-patient.md)
* [Fiji Practitioner Role](StructureDefinition-fiji-practitioner-role.md)
* [Fiji Practitioner](StructureDefinition-fiji-practitioner.md)

### Extensions

* [Island](StructureDefinition-pacific-address-island.md)
* [Village](StructureDefinition-pacific-address-village.md)
* [Pacific Clan Affiliation](StructureDefinition-pacific-clan-affiliation.md)

### ImplementationGuides

* [Fiji Core FHIR Implementation Guide](index.md)

### Examples

* [Suva Divisional Hospital (Organization)](Organization-PacificHospitalExample.md)
* [PacificPatientExample1 (Patient)](Patient-PacificPatientExample1.md)
* [PacificPatientExample2 (Patient)](Patient-PacificPatientExample2.md)
* [PacificPatientFijiITaukei (Patient)](Patient-PacificPatientFijiITaukei.md)
* [PacificPatientFijiIndo (Patient)](Patient-PacificPatientFijiIndo.md)
* [PacificPractitionerExample (Practitioner)](Practitioner-PacificPractitionerExample.md)
* [PacificPractitionerRoleExample (PractitionerRole)](PractitionerRole-PacificPractitionerRoleExample.md)
